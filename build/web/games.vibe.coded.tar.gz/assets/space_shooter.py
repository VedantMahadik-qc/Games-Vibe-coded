import pygame
import sys
import random
import asyncio

# --- INIT ---
pygame.init()
pygame.mixer.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Space Shooter")
clock = pygame.time.Clock()
font       = pygame.font.SysFont("Arial", 28)
font_large = pygame.font.SysFont("Arial", 52, bold=True)

# --- COLORS ---
BLACK   = (0,   0,   0  )
CYAN    = (0,   255, 255)
YELLOW  = (255, 255, 0  )
RED     = (220, 50,  50 )
WHITE   = (255, 255, 255)
GREY    = (180, 180, 180)
ORANGE  = (255, 165, 0  )
GREEN   = (0,   255, 100)
BLUE    = (0,   150, 255)
PURPLE  = (180, 0,   255)

# --- SOUNDS ---
shoot_sfx     = pygame.mixer.Sound("shoot.ogg")
explosion_sfx = pygame.mixer.Sound("explosion.ogg")
hit_sfx       = pygame.mixer.Sound("hit.ogg")
gameover_sfx  = pygame.mixer.Sound("gameover.ogg")

shoot_sfx.set_volume(0.4)
explosion_sfx.set_volume(0.6)
hit_sfx.set_volume(0.5)
gameover_sfx.set_volume(0.7)

# --- BACKGROUND MUSIC ---
pygame.mixer.music.load("music.ogg")
pygame.mixer.music.set_volume(0.3)
pygame.mixer.music.play(-1)

# --- STARS ---
stars = [(random.randint(0, WIDTH), random.randint(0, HEIGHT), random.randint(1, 3)) for _ in range(120)]

def draw_stars(surface):
    for x, y, size in stars:
        pygame.draw.circle(surface, GREY, (x, y), size)

def scroll_stars():
    global stars
    stars = [(x, (y + 1) % HEIGHT, size) for x, y, size in stars]

# --- PLAYER ---
class Player:
    def __init__(self):
        self.rect       = pygame.Rect(WIDTH // 2 - 25, HEIGHT - 80, 50, 40)
        self.base_speed = 6
        self.speed      = 6
        self.lives      = 3

    def move(self, keys):
        if keys[pygame.K_LEFT]  and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < WIDTH:
            self.rect.x += self.speed

    def draw(self, surface):
        pygame.draw.polygon(surface, CYAN, [
            (self.rect.centerx, self.rect.top),
            (self.rect.left,    self.rect.bottom),
            (self.rect.right,   self.rect.bottom),
        ])
        pygame.draw.circle(surface, ORANGE, (self.rect.centerx, self.rect.bottom), 6)

# --- BULLET ---
class Bullet:
    def __init__(self, x, y):
        self.rect  = pygame.Rect(x - 3, y, 6, 15)
        self.speed = 10

    def update(self):
        self.rect.y -= self.speed

    def draw(self, surface):
        pygame.draw.rect(surface, YELLOW, self.rect, border_radius=3)

# --- ENEMY ---
class Enemy:
    def __init__(self, speed):
        self.rect  = pygame.Rect(random.randint(20, WIDTH - 60), -40, 40, 40)
        self.speed = speed

    def update(self):
        self.rect.y += self.speed

    def draw(self, surface):
        pygame.draw.polygon(surface, RED, [
            (self.rect.centerx, self.rect.bottom),
            (self.rect.left,    self.rect.top),
            (self.rect.right,   self.rect.top),
        ])
        pygame.draw.circle(surface, ORANGE, (self.rect.centerx, self.rect.top), 5)

# --- BOSS ---
class Boss:
    def __init__(self):
        self.rect      = pygame.Rect(WIDTH // 2 - 60, -120, 120, 80)
        self.speed     = 2
        self.direction = 1
        self.hp        = 15
        self.max_hp    = 15

    def update(self):
        if self.rect.top < 60:
            self.rect.y += self.speed
        else:
            self.rect.x += self.speed * self.direction
            if self.rect.right >= WIDTH or self.rect.left <= 0:
                self.direction *= -1

    def draw(self, surface):
        pygame.draw.rect(surface, PURPLE, self.rect, border_radius=10)
        pygame.draw.circle(surface, RED,    (self.rect.left  + 25, self.rect.centery), 10)
        pygame.draw.circle(surface, RED,    (self.rect.right - 25, self.rect.centery), 10)
        pygame.draw.circle(surface, YELLOW, (self.rect.left  + 25, self.rect.centery), 5 )
        pygame.draw.circle(surface, YELLOW, (self.rect.right - 25, self.rect.centery), 5 )
        pygame.draw.rect(surface, RED,   (self.rect.left, self.rect.bottom + 8, self.rect.width, 10))
        hp_width = int(self.rect.width * (self.hp / self.max_hp))
        pygame.draw.rect(surface, GREEN, (self.rect.left, self.rect.bottom + 8, hp_width, 10))

# --- PARTICLE ---
class Particle:
    def __init__(self, x, y):
        self.x     = x
        self.y     = y
        self.dx    = random.uniform(-3, 3)
        self.dy    = random.uniform(-4, 1)
        self.size  = random.randint(3, 7)
        self.life  = 30
        self.color = random.choice([
            (255, 100, 0),
            (255, 50,  50),
            (255, 200, 0),
        ])

    def update(self):
        self.x    += self.dx
        self.y    += self.dy
        self.size  = max(0, self.size - 0.2)
        self.life -= 1

    def draw(self, surface):
        if self.size > 0:
            pygame.draw.circle(surface, self.color, (int(self.x), int(self.y)), int(self.size))

# --- POWERUP ---
class Powerup:
    def __init__(self, x, y):
        self.type  = random.choice(["double", "shield", "speed"])
        self.rect  = pygame.Rect(x - 10, y, 20, 20)
        self.speed = 3
        self.colors = {
            "double": BLUE,
            "shield": GREEN,
            "speed":  YELLOW,
        }

    def update(self):
        self.rect.y += self.speed

    def draw(self, surface):
        color = self.colors[self.type]
        pygame.draw.rect(surface, color, self.rect, border_radius=5)
        label = font.render(self.type[0].upper(), True, BLACK)
        surface.blit(label, (self.rect.x + 3, self.rect.y + 1))

# --- HIGH SCORE ---
def load_highscore():
    try:
        with open("highscore.txt", "r") as f:
            return int(f.read())
    except:
        return 0

def save_highscore(score):
    try:
        with open("highscore.txt", "w") as f:
            f.write(str(score))
    except:
        pass

# --- HUD ---
def draw_hud(score, lives, level, highscore, double_shot, shield_active, speed_boost):
    screen.blit(font.render(f"Score: {score}",     True, WHITE),  (10, 10))
    screen.blit(font.render(f"Lives: {lives}",     True, WHITE),  (WIDTH - 130, 10))
    screen.blit(font.render(f"Level: {level}",     True, CYAN),   (WIDTH // 2 - 50, 10))
    screen.blit(font.render(f"Best:  {highscore}", True, YELLOW), (10, 45))
    if double_shot:
        screen.blit(font.render("DOUBLE SHOT", True, BLUE),   (10, 80 ))
    if shield_active:
        screen.blit(font.render("SHIELD ON",   True, GREEN),  (10, 110))
    if speed_boost:
        screen.blit(font.render("SPEED BOOST", True, YELLOW), (10, 140))

# --- GAME OVER SCREEN ---
async def game_over_screen(score):
    pygame.mixer.music.stop()
    gameover_sfx.play()
    highscore = load_highscore()
    screen.fill(BLACK)
    draw_stars(screen)
    title   = font_large.render("GAME  OVER",             True, RED   )
    s_text  = font.render(f"Final Score: {score}",        True, WHITE )
    hs_text = font.render("New High Score!",               True, YELLOW) if score >= highscore else font.render(f"Best Score: {highscore}", True, GREY)
    restart = font.render("Press R to Restart",           True, CYAN  )
    quit_t  = font.render("Press Q to Quit",              True, GREY  )
    screen.blit(title,   (WIDTH // 2 - title.get_width()   // 2, 160))
    screen.blit(s_text,  (WIDTH // 2 - s_text.get_width()  // 2, 250))
    screen.blit(hs_text, (WIDTH // 2 - hs_text.get_width() // 2, 295))
    screen.blit(restart, (WIDTH // 2 - restart.get_width() // 2, 350))
    screen.blit(quit_t,  (WIDTH // 2 - quit_t.get_width()  // 2, 395))
    pygame.display.flip()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
        keys = pygame.key.get_pressed()
        if keys[pygame.K_q]: pygame.quit(); sys.exit()
        if keys[pygame.K_r]: return True
        await asyncio.sleep(0)
    return False

# --- MAIN GAME ---
async def run_game():
    pygame.mixer.music.play(-1)
    highscore     = load_highscore()
    player        = Player()
    bullets       = []
    enemies       = []
    particles     = []
    powerups      = []
    boss          = None
    score         = 0
    enemy_speed   = 2
    level         = 1
    shoot_cd      = 0
    SHOOT_DELAY   = 15
    enemy_timer   = 0
    ENEMY_SPAWN   = 60
    double_shot   = False
    double_timer  = 0
    shield_active = False
    shield_timer  = 0
    speed_boost   = False
    speed_timer   = 0

    while True:
        clock.tick(60)
        screen.fill(BLACK)
        scroll_stars()
        draw_stars(screen)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()

        keys = pygame.key.get_pressed()
        player.move(keys)

        # Shooting
        if shoot_cd > 0: shoot_cd -= 1
        if keys[pygame.K_SPACE] and shoot_cd == 0:
            if double_shot:
                bullets.append(Bullet(player.rect.centerx - 15, player.rect.top))
                bullets.append(Bullet(player.rect.centerx + 15, player.rect.top))
            else:
                bullets.append(Bullet(player.rect.centerx, player.rect.top))
            shoot_sfx.play()
            shoot_cd = SHOOT_DELAY

        # Spawn enemies
        if boss is None:
            enemy_timer += 1
            if enemy_timer >= ENEMY_SPAWN:
                enemies.append(Enemy(enemy_speed))
                enemy_timer = 0

        # Spawn boss every 20 kills
        if score > 0 and score % 20 == 0 and boss is None:
            boss = Boss()

        # Update bullets
        for bullet in bullets[:]:
            bullet.update()
            if bullet.rect.bottom < 0:
                bullets.remove(bullet)

        # Update enemies + collisions
        for enemy in enemies[:]:
            enemy.update()
            hit = False

            if enemy.rect.top > HEIGHT:
                enemies.remove(enemy)
                player.lives -= 1
                hit_sfx.play()
                hit = True

            if not hit:
                for bullet in bullets[:]:
                    if enemy.rect.colliderect(bullet.rect):
                        for _ in range(12):
                            particles.append(Particle(enemy.rect.centerx, enemy.rect.centery))
                        if random.random() < 0.3:
                            powerups.append(Powerup(enemy.rect.centerx, enemy.rect.centery))
                        enemies.remove(enemy)
                        bullets.remove(bullet)
                        explosion_sfx.play()
                        score += 1
                        if score % 5 == 0:
                            enemy_speed       = min(enemy_speed + 0.5, 10)
                            ENEMY_SPAWN       = max(ENEMY_SPAWN - 3, 20)
                            level            += 1
                            player.base_speed = min(player.base_speed + 0.5, 12)
                            if not speed_boost:
                                player.speed  = player.base_speed
                        hit = True
                        break

            if not hit and enemy.rect.colliderect(player.rect):
                enemies.remove(enemy)
                if shield_active:
                    shield_active = False
                    shield_timer  = 0
                else:
                    player.lives -= 1
                    hit_sfx.play()
                hit = True

        # Boss logic
        if boss:
            boss.update()
            boss.draw(screen)
            for bullet in bullets[:]:
                if boss.rect.colliderect(bullet.rect):
                    bullets.remove(bullet)
                    boss.hp -= 1
                    for _ in range(6):
                        particles.append(Particle(bullet.rect.centerx, bullet.rect.centery))
                    if boss.hp <= 0:
                        for _ in range(40):
                            particles.append(Particle(boss.rect.centerx, boss.rect.centery))
                        explosion_sfx.play()
                        score += 10
                        boss   = None
                    break
            if boss and boss.rect.colliderect(player.rect):
                if shield_active:
                    shield_active = False
                    shield_timer  = 0
                else:
                    player.lives -= 1
                    hit_sfx.play()

        # Game over
        if player.lives <= 0:
            if score > highscore:
                save_highscore(score)
            return score

        # Powerup timers
        if double_timer > 0:
            double_timer -= 1
        else:
            double_shot = False

        if shield_timer > 0:
            shield_timer -= 1
        else:
            shield_active = False

        if speed_timer > 0:
            speed_timer  -= 1
            player.speed  = 12
        else:
            speed_boost  = False
            player.speed = player.base_speed

        # Update + collect powerups
        for powerup in powerups[:]:
            powerup.update()
            powerup.draw(screen)
            if powerup.rect.top > HEIGHT:
                powerups.remove(powerup)
            elif powerup.rect.colliderect(player.rect):
                if powerup.type == "double":
                    double_shot  = True
                    double_timer = 300
                elif powerup.type == "shield":
                    shield_active = True
                    shield_timer  = 300
                elif powerup.type == "speed":
                    speed_boost = True
                    speed_timer = 300
                powerups.remove(powerup)

        # Update + draw particles
        for particle in particles[:]:
            particle.update()
            particle.draw(screen)
            if particle.life <= 0:
                particles.remove(particle)

        # Draw everything
        player.draw(screen)
        if shield_active:
            pygame.draw.circle(screen, GREEN, player.rect.center, 40, 2)
        for bullet in bullets: bullet.draw(screen)
        for enemy  in enemies: enemy.draw(screen)
        draw_hud(score, player.lives, level, highscore, double_shot, shield_active, speed_boost)
        await asyncio.sleep(0)
        pygame.display.flip()

# --- ENTRY POINT ---
async def main():
    while True:
        final_score = await run_game()
        should_restart = await game_over_screen(final_score)
        if not should_restart:
            break

asyncio.run(main())
