import pygame
import sys
import random

# --- INIT ---
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Space Shooter")
clock = pygame.time.Clock()
font       = pygame.font.SysFont("Arial", 28)
font_large = pygame.font.SysFont("Arial", 52, bold=True)

# --- COLORS ---
BLACK  = (0,   0,   0  )
CYAN   = (0,   255, 255)
YELLOW = (255, 255, 0  )
RED    = (220, 50,  50 )
WHITE  = (255, 255, 255)
GREY   = (180, 180, 180)
ORANGE = (255, 165, 0  )

# --- STARS ---
stars = [(random.randint(0, WIDTH), random.randint(0, HEIGHT), random.randint(1, 3)) for _ in range(120)]

def draw_stars(surface):
    for x, y, size in stars:
        pygame.draw.circle(surface, GREY, (x, y), size)

def scroll_stars():
    global stars
    stars = [(x, (y + 1) % HEIGHT, size) for x, y, size in stars]

# --- PLAYER ---
class Player:
    def __init__(self):
        self.rect  = pygame.Rect(WIDTH // 2 - 25, HEIGHT - 80, 50, 40)
        self.speed = 6
        self.lives = 3

    def move(self, keys):
        if keys[pygame.K_LEFT]  and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < WIDTH:
            self.rect.x += self.speed

    def draw(self, surface):
        pygame.draw.polygon(surface, CYAN, [
            (self.rect.centerx, self.rect.top),
            (self.rect.left,    self.rect.bottom),
            (self.rect.right,   self.rect.bottom),
        ])
        pygame.draw.circle(surface, ORANGE, (self.rect.centerx, self.rect.bottom), 6)

# --- BULLET ---
class Bullet:
    def __init__(self, x, y):
        self.rect  = pygame.Rect(x - 3, y, 6, 15)
        self.speed = 10

    def update(self):
        self.rect.y -= self.speed

    def draw(self, surface):
        pygame.draw.rect(surface, YELLOW, self.rect, border_radius=3)

# --- ENEMY ---
class Enemy:
    def __init__(self, speed):
        self.rect  = pygame.Rect(random.randint(20, WIDTH - 60), -40, 40, 40)
        self.speed = speed

    def update(self):
        self.rect.y += self.speed

    def draw(self, surface):
        pygame.draw.polygon(surface, RED, [
            (self.rect.centerx, self.rect.bottom),
            (self.rect.left,    self.rect.top),
            (self.rect.right,   self.rect.top),
        ])
        pygame.draw.circle(surface, ORANGE, (self.rect.centerx, self.rect.top), 5)

# --- HUD ---
def draw_hud(score, lives, level):
    score_text = font.render(f"Score: {score}", True, WHITE)
    lives_text = font.render(f"Lives: {lives}", True, WHITE)
    level_text = font.render(f"Level: {level}", True, CYAN)
    screen.blit(score_text, (10, 10))
    screen.blit(lives_text, (WIDTH - 130, 10))
    screen.blit(level_text, (WIDTH // 2 - level_text.get_width() // 2, 10))

# --- GAME OVER SCREEN ---
def game_over_screen(score):
    screen.fill(BLACK)
    draw_stars(screen)
    title   = font_large.render("GAME  OVER",       True, RED)
    s_text  = font.render(f"Final Score: {score}",  True, WHITE)
    restart = font.render("Press R to Restart",     True, CYAN)
    quit_t  = font.render("Press Q to Quit",        True, GREY)
    screen.blit(title,   (WIDTH // 2 - title.get_width()   // 2, 180))
    screen.blit(s_text,  (WIDTH // 2 - s_text.get_width()  // 2, 270))
    screen.blit(restart, (WIDTH // 2 - restart.get_width() // 2, 330))
    screen.blit(quit_t,  (WIDTH // 2 - quit_t.get_width()  // 2, 380))
    pygame.display.flip()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
        keys = pygame.key.get_pressed()
        if keys[pygame.K_q]: pygame.quit(); sys.exit()
        if keys[pygame.K_r]: return True
    return False

# --- MAIN GAME ---
def run_game():
    player      = Player()
    bullets     = []
    enemies     = []
    score       = 0
    enemy_speed = 2
    level       = 1
    shoot_cd    = 0
    SHOOT_DELAY = 15
    enemy_timer = 0
    ENEMY_SPAWN = 60

    while True:
        clock.tick(60)
        screen.fill(BLACK)
        scroll_stars()
        draw_stars(screen)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()

        keys = pygame.key.get_pressed()
        player.move(keys)

        # Shooting
        if shoot_cd > 0: shoot_cd -= 1
        if keys[pygame.K_SPACE] and shoot_cd == 0:
            bullets.append(Bullet(player.rect.centerx, player.rect.top))
            shoot_cd = SHOOT_DELAY

        # Spawn enemies
        enemy_timer += 1
        if enemy_timer >= ENEMY_SPAWN:
            enemies.append(Enemy(enemy_speed))
            enemy_timer = 0

        # Update bullets
        for bullet in bullets[:]:
            bullet.update()
            if bullet.rect.bottom < 0:
                bullets.remove(bullet)

        # Update enemies + collisions
        for enemy in enemies[:]:
            enemy.update()
            hit = False

            if enemy.rect.top > HEIGHT:
                enemies.remove(enemy)
                player.lives -= 1
                hit = True

            if not hit:
                for bullet in bullets[:]:
                    if enemy.rect.colliderect(bullet.rect):
                        enemies.remove(enemy)
                        bullets.remove(bullet)
                        score += 1
                        if score % 5 == 0:
                            enemy_speed = min(enemy_speed + 0.5, 10)
                            ENEMY_SPAWN = max(ENEMY_SPAWN - 3, 20)
                            level += 1
                        hit = True
                        break

            if not hit and enemy.rect.colliderect(player.rect):
                enemies.remove(enemy)
                player.lives -= 1
                hit = True

        if player.lives <= 0:
            return score

        # Draw
        player.draw(screen)
        for bullet in bullets:  bullet.draw(screen)
        for enemy  in enemies:  enemy.draw(screen)
        draw_hud(score, player.lives, level)
        pygame.display.flip()

# --- ENTRY POINT ---
while True:
    final_score = run_game()
    should_restart = game_over_screen(final_score)
    if not should_restart:
        break
